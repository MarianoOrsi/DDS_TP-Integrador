-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 12-07-2012 a las 15:36:42
-- Versión del servidor: 5.5.8
-- Versión de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `minifacebook`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `amigos`
--

CREATE TABLE IF NOT EXISTS `amigos` (
  `id` int(254) NOT NULL,
  `user_id1` int(254) NOT NULL,
  `user_id2` int(254) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `amigos`
--

INSERT INTO `amigos` (`id`, `user_id1`, `user_id2`) VALUES
(1, 4, 5),
(4, 1, 5),
(5, 4, 7),
(6, 5, 7),
(7, 5, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `amistades`
--

CREATE TABLE IF NOT EXISTS `amistades` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `userid1` int(2) NOT NULL,
  `userid2` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Volcar la base de datos para la tabla `amistades`
--

INSERT INTO `amistades` (`id`, `userid1`, `userid2`) VALUES
(1, 1, 2),
(3, 1, 3),
(5, 1, 11),
(8, 1, 2),
(12, 1, 2),
(13, 1, 2),
(14, 1, 2),
(15, 1, 2),
(16, 1, 2),
(18, 1, 3),
(19, 1, 6),
(22, 1, 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `nomusu` varchar(50) NOT NULL,
  `texto` varchar(2000) NOT NULL,
  `hora` varchar(50) NOT NULL,
  `idusu` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Volcar la base de datos para la tabla `post`
--

INSERT INTO `post` (`id`, `nomusu`, `texto`, `hora`, `idusu`) VALUES
(44, 'nico', 'hola que tal', '00:04:01 10-07-2012', 3),
(45, 'luca', 'ahora va?', '00:04:20 10-07-2012', 11),
(46, 'osval', 'hola que tal', '00:06:16 10-07-2012', 18),
(48, 'cris', 'hola soy cristian', '00:27:17 10-07-2012', 7),
(49, 'cris', 'hello?', '00:27:23 10-07-2012', 7),
(50, 'gonza', 'sisi se ve, como va?', '00:27:51 10-07-2012', 2),
(51, 'nico', 'Hola chicos, alguien sabe de cris?', '00:28:07 10-07-2012', 3),
(52, 'lean', 'Hola que tal!', '17:15:57 11-07-2012', 1),
(54, 'lean', 'Hola soy lean', '17:48:02 11-07-2012', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Volcar la base de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `mail`, `pass`) VALUES
(1, 'Leandro', 'Wagner', 'lean', 'lean'),
(2, 'Gonzalo', 'Consorti', 'gonza', 'gonza'),
(3, 'Nicolas', 'Guizzi', 'nico', 'nico'),
(4, 'Martin', 'Fernandez', 'martin', 'martin'),
(5, 'Demian', 'Centurion', 'demian', 'demian'),
(6, 'Matias', 'Lazarte', 'mati', 'mati'),
(7, 'Cristian', 'Puca', 'cris', 'cris'),
(8, 'Lucas', 'Rodriguez', 'lucas', 'lucas'),
(9, 'Mauro', 'Tedesco', 'chachi', 'chachi'),
(10, 'Luciano', 'Agueli', 'lucho', 'lucho'),
(11, 'Luca', 'De la Iglesia', 'luca', 'luca'),
(13, 'PEPE', 'PEPE', 'PEPE', 'PEPE'),
(18, 'Osvaldo', 'Wagner', 'osval', 'osval'),
(17, 'Agustina', 'Wagner', 'agus', 'agus'),
(20, 'Silvana', 'Calandra', 'sil', 'sil');
